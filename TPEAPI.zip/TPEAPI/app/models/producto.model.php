<?php
require_once './app/models/db.model.php';
require_once './database/config.php';

class ProductoModel extends Model{

    function getProductos($sort, $order){
        $query = $this->db->prepare("SELECT * FROM productos ORDER BY $sort $order");
        $query->execute();
        
        $productos = $query->fetchAll(PDO::FETCH_OBJ);

        return $productos;

    }

    //Trae un producto específico por id
    public function getProducto($id){
        $query = $this->db->prepare('SELECT * FROM productos p INNER JOIN categorias c ON p.id_categoria = c.id_categoria WHERE id_producto = ?');
        $query->execute([$id]);

        $producto = $query->fetch(PDO::FETCH_OBJ);
        return $producto;
    }

    public function deleteProducto($id_producto){
        $query = $this->db->prepare('DELETE FROM productos WHERE id_producto = ?');
        $query->execute([$id_producto]);
    }

    public function updateProducto($nombre, $cantidad, $descripcion, $precio, $id_producto, $id_categoria) {    
        $query = $this->db->prepare("UPDATE productos SET nombre = ? , cantidad = ? , descripcion = ? , precio = ?, id_categoria = ? WHERE id_producto = ?");
        $query->execute([$nombre, $cantidad, $descripcion, $precio, $id_categoria, $id_producto]);
    }

    function addProducto($nombre, $cantidad, $descripcion, $precio, $id_categoria) {
        $query = $this->db->prepare('INSERT INTO productos (nombre, cantidad, descripcion, precio, id_categoria) VALUES(?,?,?,?,?)');
        $query->execute([$nombre, $cantidad, $descripcion, $precio, $id_categoria]);

        return $this->db->LastInsertId();
    }

    public function getCampos(){
        $query = $this->db->prepare("DESCRIBE productos");
        $query->execute();
        return $query->fetchAll(PDO::FETCH_OBJ);
    }
}