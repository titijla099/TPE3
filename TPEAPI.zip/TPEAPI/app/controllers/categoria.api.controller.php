<?php
    require_once 'app/models/categoria.model.php';
    require_once 'app/controllers/api.controller.php';

    Class CategoriaApiController extends ApiController{
        private $model;

        function __construct(){
            parent::__construct();
            $this->model = new CategoriaModel();
        }

        public function get($params = []){
            if (empty($params)){
                $categorias = $this->model->getCategorias();
                $this->view->response($categorias, 200);
            }
            else{
                $categoria = $this->model->getCategoria($params[':ID']);
                if(empty($categoria))
                    $this->view->response(['ERROR' => 'El producto de id = ' . $params[':ID'] . ' no existe'], 404);
                else 
                    $this->view->response($categoria, 200);
            }
        }

        public function create($params = []){
            $user = $this->authHelper->actualUser();

            if(empty($user)){
                $this->view->response(['ERROR' => 'Usted no tiene autorizacion para crear una categoria'], 401);
                return;
            }

            if($user->username != 'webadmin'){
                $this->view->response('Forbidden', 403);
                return;
            }
            
            $body = $this->getData();

            if(empty($body->nombreCat) || empty($body->precauciones)){
                $this->view->response(['ERROR' => 'Complete todos los campos necesarios'], 400);
                return;
            }
            else{
                $nombreCat = $body->nombreCat;
                $precauciones = $body->precauciones;

                $id = $this->model->addCategoria($nombreCat, $precauciones);
    
                if($id){
                    $categoria = $this->model->getCategoria($id);
                    $this->view->response($categoria, 201);
                } else{
                    $this->view->response(['ERROR' => 'Ocurrio un error al intentar crear la categoria', 500]);
                }
            }

        }

        public function update($params = []){
            $user = $this->authHelper->actualUser();

            if(empty($user)){
                $this->view->response(['ERROR' => 'Usted no tiene autorizacion para crear un producto'], 401);
                return;
            }

            if($user->username != 'webadmin'){
                $this->view->response('Forbidden', 403);
                return;
            }

            $id = $params[':ID'];
            $categoria = $this->model->getCategoria($id);

            if($categoria) {
                $body = $this->getData();

                if (isset($body->nombreCat) || isset($body->precauciones)){
                    
                    $nombreCat = $body->nombreCat;
                    $precauciones = $body->precauciones;

                    $this->model->updateCategoria($nombreCat, $precauciones, $id);
                    $this->view->response('La categoria con id = '.$id.' ha sido modificada.', 200);
                }
            } 
            else {
                $this->view->response('La tarea con id='.$id.' no existe.', 404);
            }
        }

    }
