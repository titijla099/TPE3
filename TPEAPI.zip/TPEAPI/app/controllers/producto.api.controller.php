<?php
    require_once 'app/models/producto.model.php';
    require_once 'app/controllers/api.controller.php';

    Class ProductoApiController extends ApiController{
        private $model;

        function __construct(){
            parent::__construct();
            $this->model = new ProductoModel();
        }

        public function getAll($params = []){
            if((isset($_GET["sort"]) && isset($_GET["order"])) && ($_GET["order"] == 'ASC' || $_GET["order"] == 'DESC')){

                $sort = $_GET["sort"];
                $order = $_GET["order"];
                $campos = $this->model->getCampos();
                $flag = false;
                
                foreach($campos as $campo){
                    if($sort == $campo->Field){
                        $flag = true;
                    }
                }
                if($flag){
                    $productos = $this->model->getProductos($sort, $order);
                    $this->view->response($productos, 200);
                }
                else{
                    $this->view->response(['ERROR'=>'Ingrese correctamente los datos.'], 400);
                }
            }
            else{
                $sort = 'id_producto';
                $order = 'ASC';
                $productos = $this->model->getProductos($sort, $order);
                $this->view->response($productos, 200);
            }
        }

        public function getProducto($params = []){
            $producto = $this->model->getProducto($params[':ID']);
            if(empty($producto)){
                $this->view->response(['ERROR' => 'El producto de id = ' . $params[':ID'] . ' no existe'], 404);
                return;
            }
            else 
                $this->view->response($producto, 200);
        }

        public function create($params = []){
            $user = $this->authHelper->actualUser();

            if(empty($user)){
                $this->view->response(['ERROR' => 'Usted no tiene autorizacion para crear un producto'], 401);
                return;
            }

            if($user->username != 'webadmin'){
                $this->view->response('Forbidden', 403);
                return;
            }
            
            $body = $this->getData();

            if(empty($body->nombre) || empty($body->cantidad) || empty($body->descripcion) || empty($body->precio) || empty($body->id_categoria)){
                $this->view->response(['ERROR' => 'Complete todos los campos necesarios'], 400);
                return;
            }
            else{
                $nombre = $body->nombre;
                $cantidad = $body->cantidad;
                $descripcion = $body->descripcion;
                $precio = $body->precio;
                $id_categoria = $body->id_categoria;

                $id = $this->model->addProducto($nombre, $cantidad, $descripcion, $precio, $id_categoria);
    
                if($id){
                    $producto = $this->model->getProducto($id);
                    $this->view->response($producto, 201);
                } else{
                    $this->view->response(['ERROR' => 'Ocurrio un error al intentar crear el producto', 500]);
                }
            }

        }

        public function update($params = []){
            $user = $this->authHelper->actualUser();

            if(empty($user)){
                $this->view->response(['ERROR' => 'Usted no tiene autorizacion para crear un producto'], 401);
                return;
            }

            if($user->username != 'webadmin'){
                $this->view->response('Forbidden', 403);
                return;
            }

            $id = $params[':ID'];
            $producto = $this->model->getProducto($id);

            if($producto) {
                $body = $this->getData();

                if (isset($body->nombre) || isset($body->cantidad) || isset($body->descripcion) || isset($body->precio) || isset($body->id_categoria)){
                    
                    $nombre = $body->nombre;
                    $cantidad = $body->cantidad;
                    $descripcion = $body->descripcion;
                    $precio = $body->precio;
                    $id_categoria = $body->id_categoria;

                    $this->model->updateProducto($nombre, $cantidad, $descripcion, $precio, $id ,$id_categoria);
                    $this->view->response('El producto con id = '.$id.' ha sido modificado.', 200);
                }
            } 
            else {
                $this->view->response('La tarea con id='.$id.' no existe.', 404);
            }

        }

        public function delete($params = []){
            $id = $params[':ID'];
            $producto = $this->model->getProducto($id);

            if($producto){
                $this->model->deleteProducto($id);
                $this->view->response('El producto de ID ='.$id.' ha sido eliminado.', 200);
            } else{
                    $this->view->response('El producto de ID = '.$id.' no se encontró.', 404);    
            }
        }

    }