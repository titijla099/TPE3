<?php
    require_once 'app/models/user.model.php';
    require_once 'app/controllers/api.controller.php';

    Class UserApiController extends ApiController{
        private $model;

        function __construct(){
            parent::__construct();
            $this->model = new UserModel();
        }

        public function getToken(){
            $basic = $this->authHelper->getAuthHeaders();

            if(empty($basic)){
                $this->view->response(['ERROR' => 'No envió encabezados de autenticación.'], 401);
                return;
            }

            $basic = explode(" ", $basic);
            if($basic[0]!="Basic") {
                $this->view->response('Los encabezados de autenticación son incorrectos.', 401);
                return;
            }

            $userpass = base64_decode($basic[1]); // usr:pass
            $userpass = explode(":", $userpass); // ["usr", "pass"]

            $username = $userpass[0];
            $password = $userpass[1];

            $user = $this->model->getUser($username);

            if($user && password_verify($password, $user->password)){ //
                $token = $this->authHelper->createToken($user); 
                $this->view->response($token);
            } else{
                $this->view->response(['ERROR'=>'El usuario o contraseña son incorrectos'], 401);
                return;
            }
        }
    }