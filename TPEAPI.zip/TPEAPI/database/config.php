<?php
    const MYSQL_USER = 'root';
    const MYSQL_PASS = '';
    const MYSQL_DB = 'db_oneshine';
    const MYSQL_HOST = 'localhost';
    const DB_Charset = 'utf8mb4';
    const JWT_KEY = 'Hola12222!!!%';

