<?php 
    require_once 'libs/router.php';

    require_once 'app/controllers/producto.api.controller.php';
    require_once 'app/controllers/categoria.api.controller.php';
    require_once 'app/controllers/user.api.controller.php';
    
    $router = new Router();

    #                  endpoint     verbo           controller      metodo              
    $router->addRoute('productos',     'GET',    'ProductoApiController', 'getAll'     );
    $router->addRoute('productos/:ID', 'GET',    'ProductoApiController', 'getProducto');
    $router->addRoute('productos/:ID', 'DELETE', 'ProductoApiController', 'delete'  );
    $router->addRoute('productos/:ID', 'PUT',    'ProductoApiController', 'update'  );
    $router->addRoute('productos',     'POST',   'ProductoApiController', 'create'  );

    $router->addRoute('user/token',     'GET',    'UserApiController', 'getToken'   );

    $router->addRoute('categorias',     'GET',    'CategoriaApiController', 'get'   );
    $router->addRoute('categorias/:ID', 'GET',    'CategoriaApiController', 'get'   );
    $router->addRoute('categorias/:ID', 'PUT',    'CategoriaApiController', 'update');
    $router->addRoute('categorias',     'POST',   'CategoriaApiController', 'create');


    $router->route($_GET["resource"], $_SERVER['REQUEST_METHOD']);

