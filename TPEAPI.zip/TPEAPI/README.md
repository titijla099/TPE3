# **ONE SHINE API**

### - Descripción
Nuestra API tiene como propósito poder mostrar, agregar, borrar y  modificar nuestros productos presentes en la base de datos.
*Aclaraciones:* 

- Ante cualquier error encontrado, todas las respuestas tendrán el siguiente formato:
    ```json
    {
        "ERROR": "Mensaje del error",
        "status": "error"
    }
    ``` 

- La dirección base de la API es la siguiente:

    - **http://localhost/tucarpeta/TPEAPI/api**

------------

### - Endpoints
 - Aclaracion: Los endpoints marcados con **[TP]** (Token protected) están protegidos por **un token de autorización**
 - Para poder generar un token valido el username = 'webadmin' y el password = 'admin'. 
    
- #### /productos

    *Cada producto se listará de la siguiente manera:*
            
    ```json
        {
        "id_producto": 3,
        "nombre": "Snow Foam Shampoo",
        "cantidad": "500ml",
        "descripcion": "Shampoo PH neutro, apto para FOAM",
        "precio": 1400,
        "id_categoria": 1
        }
    ```
    #####  - GET: /productos
    - Este Endpoint devuelve la lista de todos los productos de la base de datos.

    ##### - GET: /productos/:ID
    - Este Endpoint devuelve el producto con el ID indicado.

    ##### - POST: /productos **[TP]**
    - Este endpoint recibe un objeto **JSON** en el body del **HTTP Request** para luego insertarlo en la base de datos.
        ejemplo:
        ```json
        {
            "nombre": "Snow Foam Shampoo",
            "cantidad": "500ml",
            "descripcion": "Shampoo PH neutro, apto para FOAM",
            "precio": 1400,
            "id_categoria": 1
        }
        ```
        El id de los productos son AutoIncremental asique no es necesario enviarlo en el body.
        La respuesta incluirá el producto agregado en el formato antes mostrado (Que incluye el **ID** asignado).

    ##### - PUT: /productos/:ID **[TP]**
    - Este endpoint recibe un objeto igual al anterior en el body y modifica el elemento con el **ID** dado en la base de datos.

    ##### - DELETE: /productos/:ID
    - Este endpoint elimina el producto con el **ID** indicado. De realizarse correctamente, devuelve el mensaje **"El album fue borrado con exito."** dentro del atributo **"data"** de la respuesta.



- #### Categorias

    *Cada categoria se listará de la siguiente manera:*
        
    ```json
        {
            "id_categoria": 1,
            "nombreCat": "Shampoo",
            "precauciones": 0
        }
    ```

    ##### - GET: /categorias
    - Este Endpoint devuelve una lista de las categorias guardadas en la base de datos.
        
    ##### - GET: /categorias/:ID
    - Este Endpoint devuelve una categoria solicitada mediante su **ID**.


    ##### - POST: /categorias **[TP]**
    - Este Endpoint crea una nueva categoria a partir de los datos introducidos en el body:
        ```json
         {
            "nombreCat": "Shampoo",
            "precauciones": 0
         }
         ```

        Dentro de **"data"** se devolverá la categoria creada en el mismo formato.

    ##### - PUT: /categorias/:ID **[TP]**
    - Este Endpoint permite modificar una categoria seleccionada mediante su **ID**, los datos modificables son los mismos que para el POST.



- #### Autorización
    #####  - POST: /user/token
    -  Este Endpoint recibe en el body del **HTTP Request** un objeto de tipo **JSON** con las propiedades **"username"** y **"password'**. De ser correctos los datos introducidos, se proporcionará dentro de **"data"** un token que permite identificarse.
    
   - *Ejemplo*:
    
        ```json
            //Objeto a incluir en el body del HTTP Request para generar un token valido
            {
                "name": "webadmin",
                "password": "admin"
            }
            
            //Ejemplo de la respuesta
            {
                "data": "token generado",
                "status": "success"
            }
        ```
    - El **token** generado mediante este endpoint será requerido para todos los request de tipo **POST, PUT** de las entidades de datos. Deberá agregarse a los **Headers** del request en el siguiente formato:
    
            Autorization: Bearer <Token generado>   

- #### Parámemtros de ordenamiento:
    Al solicitar una lista de entidades ***productos*** podemos usar los siguientes query params para controlar cómo se muestra la lista incluída en el altributo **"data"** de la respuesta:

    - **?sort_by** : Este parámetro recibe un string que **debe corresponder** con uno de los **campos de la tabla productos**. (De no corresponder se enviará la respuesta ordenada por el campo por defecto). **Por defecto los clasificará por "id_producto".**

    - **?order** : Este parámetro determina la manera por la cual se ordenaran los productos ya clasificados por el campo anteriormente. De no corresponder el formato por defecto se ordenan ascendentemente.


